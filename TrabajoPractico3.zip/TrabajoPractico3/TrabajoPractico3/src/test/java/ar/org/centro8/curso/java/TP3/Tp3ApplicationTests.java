package ar.org.centro8.curso.java.TP3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tp3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
