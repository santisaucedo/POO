use negocio;



SELECT p.nombre AS nombre_proveedor, ph.proveedorID, COUNT(*) AS cantidad_vendidos
FROM programacionHandys ph
JOIN proveedores p ON ph.proveedorID = p.proveedorID
GROUP BY ph.proveedorID
ORDER BY cantidad_vendidos DESC
LIMIT 5;