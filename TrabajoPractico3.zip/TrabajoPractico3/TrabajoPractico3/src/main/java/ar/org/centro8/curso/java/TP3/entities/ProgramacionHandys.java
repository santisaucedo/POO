package ar.org.centro8.curso.java.TP3.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProgramacionHandys {
    private int proveedorID;
    private String clienteID;
    private boolean productoID;
    private int programacion;
    private int fechaVenta;
}
