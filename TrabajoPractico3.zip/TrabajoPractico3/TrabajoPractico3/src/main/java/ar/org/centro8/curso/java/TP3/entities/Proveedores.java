package ar.org.centro8.curso.java.TP3.entities;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Proveedores {
    private int nombreProveedor;
    private String direccion;
    private int telefono;
    private String mail;
    private int proveedorID;
  
}
