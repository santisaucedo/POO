package ar.org.centro8.curso.java.TP3.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class EquiposController{
    
    @GetMapping("/equipos")
    public String getEquipos(){
        return "equipos";
    }

}