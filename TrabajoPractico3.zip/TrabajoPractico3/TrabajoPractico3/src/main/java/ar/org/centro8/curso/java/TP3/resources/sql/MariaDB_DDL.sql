-- Active: 1717965189508@@127.0.0.1@3306@negocio
-- extensión MySQL Weijan Chen

drop database if exists negocio;

create database negocio;

use negocio;

drop table if exists clientes;

drop table if exists proveedores;

drop table if exists equipos;

drop table if exists programacionHandys;

create table clientes (
    clienteID int auto_increment primary key,
    razonsocial varchar(25) not null,
    cuit varchar(11) not null,
    mail varchar(50) not null,
    telefono varchar(25) not null
);

create table equipos (
    productoID int auto_increment,
    clienteID int not null,
    nombre varchar(25) not null,
    descripcion varchar(25) not null,
    precio double not null,
    stock int not null,
    primary key(productoID, clienteID)
);

create table proveedores (
    proveedorID int auto_increment primary key,
    nombre varchar(25) not null,
    direccion varchar(25),
    telefono varchar(25) not null,
    mail varchar(25) not null
);

create table programacionhandys (
   	productoID int not null,
   	clienteID int not null,
    proveedorID int not null,
    programacion boolean not null,
    fechaventa date not null,
    primary key(productoID, clienteID, proveedorID)    
);

alter table equipos
add constraint FK_Equipos_clienteID foreign key (clienteID) references clientes (clienteID);

alter table programacionhandys
add constraint FK_programacionHandys_proveedorID
foreign key (proveedorID) references proveedores (proveedorID);

alter table programacionhandys
add constraint FK_programacionhandys_equipos foreign key (productoID) references equipos (productoID);






