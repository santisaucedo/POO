package ar.org.centro8.curso.java.TP3.entities;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Clientes {
    private String razonSocial;
    private int cuit;
    private String mail;
    private int telefono;
    private int clienteID;   
}
