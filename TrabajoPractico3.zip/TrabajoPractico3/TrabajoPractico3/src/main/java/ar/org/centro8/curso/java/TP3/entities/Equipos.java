package ar.org.centro8.curso.java.TP3.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Equipos {
    private String nombreProducto;
    private String Descripcion;
    private double precio;
    private int stock;
    private int productoID;
}
