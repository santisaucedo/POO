package ar.org.centro8.curso.java.TP3.test;
/*
import ar.org.centro8.curso.java.entities.Alumno;
import ar.org.centro8.curso.java.entities.Curso;

import ar.org.centro8.curso.java.repositories.AlumnoRepository;
import ar.org.centro8.curso.java.repositories.CursoRepository;
 */
public class TestRepository {
    public static void main(String[] args) {
       /* EquiposRepository cursoRepository=new EquiposRepository();

        System.out.println("-- Test Curso Repository --");
        System.out.println("-- Método .save() --");
        Clientes curso=new Clientes(
                                    0,
                                    "Java",
                                    "Torres",
                                    Dia.LUNES,
                                    Turno.NOCHE);
        cursoRepository.save(curso);
        System.out.println(curso);

        System.out.println("-- Método .getById --");
        System.out.println(cursoRepository.getById(8));

        System.out.println("-- Método remove() --");
        cursoRepository.remove(cursoRepository.getById(30));

        System.out.println("-- Método getLikeTitulo --");
        cursoRepository.getLikeTitulo("ja").forEach(System.out::println);

        System.out.println("-- Método .getAll() --");
        cursoRepository.getAll().forEach(System.out::println);

        System.out.println("-- Test Alumno Repository --");
        ClientesRepository alumnoRepository=new ClientesRepository();
        
        System.out.println("-- Método .save() --");
        Equipos alumno=new Equipos(
                                    0,
                                    "Cristian",
                                    "Cabrera",
                                    26,
                                    1);

        System.out.println(alumno);

        System.out.println("-- Método .getById() --");
        System.out.println(alumnoRepository.getById(5));

        System.out.println("-- Método remove() --");
        alumnoRepository.remove(alumnoRepository.getById(8));

        System.out.println("-- Método getLikeApellido() --");
        alumnoRepository.getLikeApellido("ez").forEach(System.out::println);

        System.out.println("-- Método .getAll() --");
        alumnoRepository.getAll().forEach(System.out::println);

 */
    }
}
