use negocio;
-- Insert sample data into the 'clientes' table
insert into clientes (razonsocial, cuit, mail, telefono) values
('Client1', '12345678901', 'client1@example.com', '123456789'),
('Client2', '23456789012', 'client2@example.com', '234567890'),
('Client3', '34567890123', 'client3@example.com', '345678901'),
('Client4', '45678901234', 'client4@example.com', '456789012'),
('Client5', '56789012345', 'client5@example.com', '567890123'),
('Client6', '67890123456', 'client6@example.com', '678901234'),
('Client7', '78901234567', 'client7@example.com', '789012345'),
('Client8', '89012345678', 'client8@example.com', '890123456'),
('Client9', '90123456789', 'client9@example.com', '901234567'),
('Client10', '01234567890', 'client10@example.com', '012345678');

-- Insert sample data into the 'equipos' table
insert into equipos (clienteID, nombre, descripcion, precio, stock) values
(1, 'Producto1', 'Descripción1', 100.00, 50),
(2, 'Producto2', 'Descripción2', 150.00, 30),
(3, 'Producto3', 'Descripción3', 200.00, 20),
(4, 'Producto4', 'Descripción4', 250.00, 40),
(5, 'Producto5', 'Descripción5', 300.00, 25),
(6, 'Producto6', 'Descripción6', 350.00, 15),
(7, 'Producto7', 'Descripción7', 400.00, 35),
(8, 'Producto8', 'Descripción8', 450.00, 45),
(9, 'Producto9', 'Descripción9', 500.00, 10),
(10, 'Producto10', 'Descripción10', 550.00, 5);

-- Insert sample data into the 'proveedores' table
insert into proveedores (nombre, direccion, telefono, mail) values
('Supplier1', 'Address1', '123456789', 'supplier1@example.com'),
('Supplier2', 'Address2', '234567890', 'supplier2@example.com'),
('Supplier3', 'Address3', '345678901', 'supplier3@example.com'),
('Supplier4', 'Address4', '456789012', 'supplier4@example.com'),
('Supplier5', 'Address5', '567890123', 'supplier5@example.com'),
('Supplier6', 'Address6', '678901234', 'supplier6@example.com'),
('Supplier7', 'Address7', '789012345', 'supplier7@example.com'),
('Supplier8', 'Address8', '890123456', 'supplier8@example.com'),
('Supplier9', 'Address9', '901234567', 'supplier9@example.com'),
('Supplier10', 'Address10', '012345678', 'supplier10@example.com');

-- Insert sample data into the 'programacionhandys' table
insert into programacionhandys (productoID, clienteID, proveedorID, programacion, fechaventa) values
(1, 1, 1, true, '2024-06-12'),
(2, 2, 2, true, '2024-06-12'),
(3, 3, 3, true, '2024-06-12'),
(4, 4, 4, true, '2024-06-12'),
(5, 5, 5, true, '2024-06-12'),
(6, 6, 6, true, '2024-06-12'),
(7, 7, 7, true, '2024-06-12'),
(8, 8, 8, true, '2024-06-12'),
(9, 9, 9, true, '2024-06-12'),
(10, 10, 10, true, '2024-06-12');

